const envs = {
    DEVELOPMENT: 'development',
    STAGING: 'staging',
    TEST: 'test',
    PROD: 'production'
};

module.exports = envs;
